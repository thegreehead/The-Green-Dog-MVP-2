# 📦 Estrutura de Pastas Completa - The Green Dog MVP

```
the-green-dog-webapp/
│
├── 📂 public/                          # Assets estáticos (públicos)
│   ├── favicon.svg
│   └── favicon.ico
│
├── 📂 src/                             # Código-fonte principal
│   │
│   ├── 📂 components/                  # Componentes reutilizáveis
│   │   ├── Header.jsx                  # Navegação (responsive + mobile menu)
│   │   ├── Footer.jsx                  # Footer + Compliance block fixo
│   │   └── [Futuros componentes]
│   │       └── Button.jsx
│   │       └── Card.jsx
│   │       └── Modal.jsx
│   │       └── LeadCaptureForm.jsx
│   │
│   ├── 📂 pages/                       # Páginas/Rotas
│   │   ├── Home.jsx                    # Home (Hero + Discovery + Education)
│   │   │
│   │   └── 📂 tutor/                   # Jornada: Tutor
│   │       ├── TutorIntro.jsx          # /tutor - Introdução acolhedora
│   │       ├── Ebook.jsx               # /tutor/ebook (FUTURA)
│   │       └── FindVet.jsx             # /tutor/veterinarios (FUTURA)
│   │
│   │   └── 📂 vet/                     # Jornada: Veterinário
│   │       ├── VetIntro.jsx            # /vet - Introdução técnica
│   │       ├── Regulation.jsx          # /vet/regulacao (FUTURA)
│   │       ├── Manual.jsx              # /vet/manual (FUTURA)
│   │       └── Library.jsx             # /vet/biblioteca (FUTURA)
│   │
│   ├── 📂 styles/                      # Estilos globais
│   │   └── globals.css                 # CSS customizado + Tailwind overrides
│   │
│   ├── 📂 utils/                       # Funções utilitárias
│   │   ├── constants.js                # Constantes globais, rotas, conteúdo
│   │   └── helpers.js                  # Funções auxiliares (FUTURA)
│   │
│   ├── 📂 context/                     # Context API (FUTURA)
│   │   └── AuthContext.jsx
│   │
│   ├── App.jsx                         # Componente raiz + Roteamento
│   ├── main.jsx                        # Vite entry point
│   └── index.css                       # Tailwind @imports
│
├── 🔨 Arquivos de Configuração
│   ├── index.html                      # Template HTML principal
│   ├── package.json                    # Dependências e scripts
│   ├── package-lock.json               # Lock file (auto-gerado)
│   ├── tailwind.config.js              # Theme, extensões Tailwind
│   ├── postcss.config.js               # PostCSS plugins
│   ├── vite.config.js                  # Configuração Vite
│   └── .gitignore                      # Ignorar files no Git
│
├── 📚 Documentação
│   ├── README.md                       # Overview, setup local, features MVP
│   ├── ARCHITECTURE.md                 # Design técnico, estrutura componentes
│   ├── DESIGN_SYSTEM.md                # Cores, tipografia, componentes UI
│   ├── QUICK_START.md                  # Guia rápido, próximos passos, roadmap
│   ├── COMPONENT_SNIPPETS.md           # Snippets de componentes reutilizáveis
│   └── FOLDER_STRUCTURE.md             # Este arquivo
│
├── 🔐 Environment
│   └── .env.local                      # Variáveis de ambiente (GITIGNORED)
│
└── .git/                               # Repositório Git (GITIGNORED)

```

## 📊 Mapa de Roteamento

```
/
├── /                                   → Home (Hero + CTAs duplos)
│
├── /tutor
│   ├── /tutor/introducao              → Introdução Tutores (TutorIntro.jsx)
│   ├── /tutor/ebook                   → Download Ebook (Futura)
│   ├── /tutor/veterinarios            → Encontrar Veterinário (Futura)
│   └── /tutor/faq                     → FAQ Tutores (Futura)
│
├── /vet
│   ├── /vet/introducao                → Introdução Técnica (VetIntro.jsx)
│   ├── /vet/regulacao                 → Panorama Regulatório (Futura)
│   ├── /vet/manual                    → Manual de Prescrição (Futura)
│   └── /vet/biblioteca                → Biblioteca Científica (Futura)
│
└── [Futuras páginas]
    ├── /sobre                         → Página institucional
    ├── /contato                       → Contato/suporte
    ├── /politica-privacidade
    └── /termos-uso
```

## 🎯 O Que Há em Cada Arquivo

### Componentes

**Header.jsx**
```
- Logo brandizada
- Navegação (menu horizontal)
- Mobile menu (click hamburger < 768px)
- Links ativos (highlight)
```

**Footer.jsx**
```
- Compliance block (OBRIGATÓRIO, verde escuro, topo)
- Brand + descrição
- 4 colunas: Brand, Tutores, Veterinários, Legal
- Redes sociais
- Copyright
```

### Pages

**Home.jsx**
```
- Hero Section (headline + dois CTAs)
- Discovery Cards (3 cards)
- Education Cards (2 cards)
- Newsletter CTA
- Trust Indicators (4 stats)
```

**TutorIntro.jsx** (/tutor)
```
- Hero acolhedor
- Módulo 1: Entenda a Dor
- Módulo 2: Cannabis Veterinária
- CTA: Download Ebook (com form)
- FAQ expandível
- CTA: Encontrar Veterinário
```

**VetIntro.jsx** (/vet)
```
- Hero técnico
- Módulo 1: Regulação & Compliance
- Módulo 2: Farmacocinética & Dosagem
- CTA: Download Manual (com CRMV field)
- Preview Biblioteca com filtros
- CTA: Acessar biblioteca completa
```

### Configuração

**tailwind.config.js**
```
- Cores: primary (verde), accent (ouro), neutral (cinza)
- Tipografia: Poppins (displays), Inter (body)
- Extensões customizadas
```

**constants.js**
```
- Rotas (ROUTES object)
- Cores (COLORS)
- Conteúdo estático (textos, headers, CTAs)
- Filtros (espécie, indicação, evidência)
- FAQ templates
```

### Documentação

**README.md** - Começa aqui
```
- Quick start (npm install, npm run dev)
- Stack tecnológico
- Features MVP
- KPIs para monitorar
```

**ARCHITECTURE.md** - Design técnico detalhado
```
- Fluxo de jornada (Tutor vs Vet)
- Estrutura de componentes
- Roteamento com React Router
- Design system (Tailwind)
```

**DESIGN_SYSTEM.md** - Referência visual
```
- Cores (hex, RGB, uso)
- Tipografia (fonts, sizes)
- Componentes (Button, Card, Input, etc)
- Espaçamento, sombras, acessibilidade
```

**QUICK_START.md** - Guia de desenvolvimento
```
- O que já está feito ✓
- Próximas fases (roadmap)
- Como trabalhar com o projeto
- Compliance checklist
```

**COMPONENT_SNIPPETS.md** - Reutilizáveis
```
- Button component
- Card component
- Input component
- Modal/Dialog
- Accordion
- Hero section
- Grid layouts
```

---

## 🚀 Árvore de Dependências

```
node_modules/
├── react (18.2.0)
├── react-dom (18.2.0)
├── react-router-dom (6.20.0)
├── tailwindcss (3.3.6)
├── vite (5.0.8)
└── [+ plugins e utilidades]
```

---

## 📈 Crescimento Futuro da Estrutura

### Após Fase 2 (Backend)
```
├── src/
│   ├── api/                            # API client
│   │   └── client.js
│   ├── hooks/                          # Custom React hooks
│   │   ├── useAuth.js
│   │   └── useFetch.js
│   └── services/                       # Business logic
│       └── authService.js
```

### Após Fase 3 (CMS Content)
```
├── src/
│   ├── content/                        # Conteúdo estático/dinâmico
│   │   ├── articles.json
│   │   └── faq.json
│   └── data/                           # Mock data
│       └── vetsList.json
```

### Após Fase 4 (Admin Dashboard)
```
├── src/
│   └── admin/                          # Área administrativa
│       ├── Dashboard.jsx
│       ├── UserManagement.jsx
│       └── ContentEditor.jsx
```

### Após Fase 5 (Mobile App)
```
mobile-app/                            # Novo repo
├── android/
├── ios/
├── src/
└── package.json
```

---

## 🎨 Convenções de Nomenclatura

### Arquivos
- **Components**: PascalCase (Header.jsx, Button.jsx)
- **Pages**: PascalCase (Home.jsx, TutorIntro.jsx)
- **Utilidades**: camelCase (constants.js, helpers.js)
- **Estilos**: kebab-case se forem CSS (global-styles.css)

### Variáveis & Funções
- **Constantes**: UPPER_SNAKE_CASE (API_URL, COMPLIANCE_MESSAGE)
- **Variáveis**: camelCase (isMenuOpen, userData)
- **Funções**: camelCase (handleSubmit, formatDate)

### CSS Classes (Tailwind)
```
.card composto por
- prefis: hover:, md:, lg:, focus:
- operação: bg-primary-600, text-white, rounded-lg
- modificadores: transition-colors, shadow-lg
```

---

## ✅ Checklist de Arquivos

Todos os arquivos listados abaixo foram criados em Phase 1:

- [x] src/components/Header.jsx
- [x] src/components/Footer.jsx
- [x] src/pages/Home.jsx
- [x] src/pages/tutor/TutorIntro.jsx
- [x] src/pages/vet/VetIntro.jsx
- [x] src/App.jsx
- [x] src/main.jsx
- [x] src/index.css
- [x] src/utils/constants.js
- [x] index.html
- [x] package.json
- [x] tailwind.config.js
- [x] postcss.config.js
- [x] vite.config.js
- [x] .gitignore
- [x] README.md
- [x] ARCHITECTURE.md
- [x] DESIGN_SYSTEM.md
- [x] QUICK_START.md
- [x] COMPONENT_SNIPPETS.md
- [x] FOLDER_STRUCTURE.md

---

**Total: 21 arquivos criados + estrutura de pastas completa** ✨

Próximo passo: `npm install && npm run dev`
