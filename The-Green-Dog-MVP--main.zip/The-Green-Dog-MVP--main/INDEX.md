# 📖 THE GREEN DOG - DOCUMENTAÇÃO INDEX

## 🎯 Por Onde Começar?

Escolha seu ponto de partida:

### 👨‍💼 Gerente de Projeto / Stakeholder
**Quer entender o projeto rapidamente?**
1. Leia: [README.md](README.md) - Overview em 5 minutos
2. Veja: [FOLDER_STRUCTURE.md](FOLDER_STRUCTURE.md) - Visualize a organização

### 👨‍💻 Developer / Frontend Engineer
**Quer começar a desenvolver?**
1. Leia: [README.md](README.md) - Setup local
2. Estude: [ARCHITECTURE.md](ARCHITECTURE.md) - Como está organizado
3. Consulte: [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md) - Componentes e estilos
4. Inicie: `npm install && npm run dev`

### 🎨 Designer / UX Engineer
**Quer entender o design system?**
1. Consulte: [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md) - Cores, tipografia, componentes
2. Explore: [COMPONENT_SNIPPETS.md](COMPONENT_SNIPPETS.md) - Padrões de UI
3. Veja: [ARCHITECTURE.md](ARCHITECTURE.md) - Fluxos de usuário

### 🚀 DevOps / Deployment Engineer
**Quer colocar em produção?**
1. Leia: [DEPLOYMENT.md](DEPLOYMENT.md) - Todas as opções de deploy
2. Consulte: [README.md](README.md) - Tecnologias usadas

### 📚 QA / Tester
**Quer testar o app?**
1. Leia: [README.md](README.md) - Features MVP implementadas
2. Consulte: [DEPLOYMENT.md](DEPLOYMENT.md) - Pre-launch checklist
3. Teste: Jornada Tutor vs Veterinário

---

## 📁 Arquivos de Documentação (em Ordem de Importância)

### 🟢 **Essencial - Comece Aqui**

| Arquivo | Descrição | Para Quem |
|---------|-----------|----------|
| **[README.md](README.md)** | Overview, setup, features MVP | Todos |
| **[QUICK_START.md](QUICK_START.md)** | Como trabalhar com projeto + próximos passos | Devs |

---

### 🟡 **Importante - Leia Depois**

| Arquivo | Descrição | Para Quem |
|---------|-----------|----------|
| **[ARCHITECTURE.md](ARCHITECTURE.md)** | Design técnico, estrutura componentes, roteamento | Devs, Arquitetos |
| **[DESIGN_SYSTEM.md](DESIGN_SYSTEM.md)** | Cores, tipografia, componentes UI standards | Designers, Devs |
| **[FOLDER_STRUCTURE.md](FOLDER_STRUCTURE.md)** | Visualização da árvore de pastas | Todos |

---

### 🔵 **Referência - Consulte Quando Precisar**

| Arquivo | Descrição | Para Quem |
|---------|-----------|----------|
| **[COMPONENT_SNIPPETS.md](COMPONENT_SNIPPETS.md)** | Snippets de componentes reutilizáveis | Devs, Designers |
| **[DEPLOYMENT.md](DEPLOYMENT.md)** | Guia de deployment em múltiplas plataformas | DevOps, Devs |

---

## 🗺️ Fluxo de Navegação na Documentação

```
START
  │
  ├─→ Gerente? ─→ README.md ─→ FOLDER_STRUCTURE.md
  │
  ├─→ Developer? ─→ README.md ─→ ARCHITECTURE.md ─→ QUICK_START.md
  │                                  ├──→ DESIGN_SYSTEM.md
  │                                  └──→ COMPONENT_SNIPPETS.md
  │
  ├─→ Designer? ─→ DESIGN_SYSTEM.md ─→ COMPONENT_SNIPPETS.md
  │
  ├─→ DevOps? ─→ DEPLOYMENT.md ─→ README.md
  │
  └─→ QA? ─→ README.md (Features) ─→ DEPLOYMENT.md (Checklist)
```

---

## 📚 Conteúdo Rápido por Arquivo

### README.md
```
✓ Quick start (3 comandos)
✓ Stack tecnológico
✓ Features MVP (checklist)
✓ Próximas fases 2-5
✓ KPIs para monitorar
```

### ARCHITECTURE.md
```
✓ Dois fluxos de jornada (Tutor vs Vet)
✓ Estrutura de componentes detalhada
✓ Páginas explicadas
✓ Roteamento da aplicação
✓ Compliance & segurança
✓ Responsividade
```

### DESIGN_SYSTEM.md
```
✓ Palette (primary/accent/neutral)
✓ Tipografia (Poppins/Inter)
✓ Componentes principais
✓ Espaçamento e sombras
✓ Acessibilidade
✓ Responsividade breakpoints
```

### QUICK_START.md
```
✓ Implementado no MVP
✓ Próximas fases (Roadmap)
✓ Como adicionar páginas/componentes
✓ Compliance checklist
✓ Dicas de desenvolvimento
```

### FOLDER_STRUCTURE.md
```
✓ Árvore completa de pastas
✓ Mapa de roteamento
✓ O que há em cada arquivo
✓ Convenções de nomenclatura
✓ Crescimento futuro
```

### COMPONENT_SNIPPETS.md
```
✓ Template Button
✓ Template Card
✓ Template Input/Form
✓ Template Modal
✓ Template Tabs
✓ Template Accordion
```

### DEPLOYMENT.md
```
✓ Build para produção
✓ Deploy em Vercel/Netlify/AWS/Firebase
✓ Configurações de segurança
✓ Performance optimization
✓ CI/CD pipelines
✓ Pre-launch checklist
```

### FOLDER_STRUCTURE.md
```
✓ Visualização ASCII da árvore
✓ Mapa de roteamento
✓ O que contém cada pasta
✓ Crescimento futuro da estrutura
```

---

## 🎯 Casos de Uso - Onde Consultar?

### "Preciso adicionar uma nova página"
1. QUICK_START.md (seção "Como adicionar páginas")
2. ARCHITECTURE.md (veja estrutura de pages/)
3. COMPONENT_SNIPPETS.md (copie um template)

### "Qual é a cor primary do site?"
1. DESIGN_SYSTEM.md (seção Cores)
2. tailwind.config.js (código)

### "Como fazer deploy?"
1. DEPLOYMENT.md (escolha a plataforma)
2. README.md (verificar stack)

### "Como criar um componente reutilizável?"
1. COMPONENT_SNIPPETS.md (veja exemplos)
2. ARCHITECTURE.md (seção Componentes)
3. DESIGN_SYSTEM.md (siga o padrão)

### "Qual é o roteamento da aplicação?"
1. ARCHITECTURE.md (seção Roteamento)
2. FOLDER_STRUCTURE.md (Mapa de roteamento)

### "O que há no MVP?"
1. README.md (seção Features MVP)
2. QUICK_START.md (Implementado no MVP)
3. ARCHITECTURE.md (Páginas explicadas)

### "Quais são as próximas fases?"
1. QUICK_START.md (Próximas Fases)
2. README.md (Próximas Fases)

### "Como a aplicação está organizada?"
1. FOLDER_STRUCTURE.md (visualize a árvore)
2. ARCHITECTURE.md (entenda os componentes)

---

## 🔗 Referências Cruzadas Rápidas

```
README.md
  ├─ Quer saber mais? → ARCHITECTURE.md
  ├─ Quer ver pastas? → FOLDER_STRUCTURE.md
  └─ Quer fazer deploy? → DEPLOYMENT.md

ARCHITECTURE.md
  ├─ Quer cores/typo? → DESIGN_SYSTEM.md
  ├─ Quer componentes? → COMPONENT_SNIPPETS.md
  └─ Quer estrutura? → FOLDER_STRUCTURE.md

DESIGN_SYSTEM.md
  ├─ Quer codes? → src/styles/, tailwind.config.js
  └─ Quer exemplos? → COMPONENT_SNIPPETS.md

QUICK_START.md
  ├─ Quer setup? → README.md
  ├─ Quer estrutura? → FOLDER_STRUCTURE.md
  └─ Quer componentes? → COMPONENT_SNIPPETS.md
```

---

## 📊 Estatísticas do Projeto

### Arquivos Criados
- **Componentes**: 2 (Header, Footer) + pages (Home, TutorIntro, VetIntro)
- **Configuração**: 4 arquivos (Vite, Tailwind, PostCSS, .gitignore)
- **Documentação**: 8 arquivos (este index + 7 guias)
- **Fonte**: constants.js
- **Total**: 22+ arquivos

### Linhas de Código (Estimado)
- **React Components**: ~1,500 LOC
- **Tailwind Config**: ~100 LOC
- **Documentação**: ~3,000 LOC
- **Total**: ~4,600 LOC

### Páginas Implementadas
- [x] Home (Hero + 4 seções)
- [x] /tutor (Introdução + FAQ + CTAs)
- [x] /vet (Técnica + Forms + Preview)
- [ ] /tutor/ebook (próxima)
- [ ] /vet/regulacao (próxima)

### Componentes do Design System
- [x] Header (navegação responsiva)
- [x] Footer (+ compliance obrigatório)
- [x] Button (primário, secundário, accent)
- [x] Card (com variants)
- [x] Form inputs
- [ ] Modal (snippet pronto)
- [ ] Tabs (snippet pronto)
- [ ] Accordion (snippet pronto)

---

## 🚀 Como Começar - Passo a Passo

### Para Todos

1. **Leia**: [README.md](README.md) (3 minutos)
2. **Clone/Acesse**: Pasta `web/`
3. **Execute**: 
   ```bash
   npm install
   npm run dev
   ```
4. **Explore**: Abra http://localhost:3000

### Para Desenvolvedores Adicionais

1. **Setup**: [README.md](README.md) - Quick Start
2. **Entenda**: [ARCHITECTURE.md](ARCHITECTURE.md)
3. **Consulte**: [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md) enquanto codifica
4. **Reutilize**: [COMPONENT_SNIPPETS.md](COMPONENT_SNIPPETS.md)
5. **Implemente**: Use [QUICK_START.md](QUICK_START.md)

### Para Deployment

1. **Leia**: [DEPLOYMENT.md](DEPLOYMENT.md)
2. **Escolha**: Vercel (recomendado), Netlify, AWS, etc.
3. **Configure**: Siga as instruções específicas da plataforma
4. **Teste**: Pre-launch checklist do [DEPLOYMENT.md](DEPLOYMENT.md)
5. **Launch**: `npm run build && npm run preview`

---

## ❓ FAQ - Documentação

**P: Qual arquivo levo para uma reunião com stakeholders?**
A: [README.md](README.md) e [FOLDER_STRUCTURE.md](FOLDER_STRUCTURE.md)

**P: Por onde um novo dev começa?**
A: [README.md](README.md) → [ARCHITECTURE.md](ARCHITECTURE.md) → `npm run dev`

**P: Onde estão as constantes globais?**
A: `src/utils/constants.js`

**P: Como adiciono uma cor customizada?**
A: [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md) + `tailwind.config.js`

**P: Qual é o compliance obrigatório?**
A: Ver [ARCHITECTURE.md](ARCHITECTURE.md) seção Compliance & Segurança

**P: Posso deletar algum arquivo?** 
A: ⚠️ Não. Todos são essenciais para MVP ou documentam decisões.

---

## 📞 Suporte

- **Erro no setup?** → Vá em [README.md](README.md) seção "Quick Start"
- **Dúvida técnica?** → Consulte [ARCHITECTURE.md](ARCHITECTURE.md)
- **Design/CSS?** → Veja [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md)
- **Como fazer algo?** → Procure em [QUICK_START.md](QUICK_START.md)
- **Deploy?** → Siga [DEPLOYMENT.md](DEPLOYMENT.md)

---

## ✅ Checklist de Onboarding

- [ ] Li README.md
- [ ] Executei `npm install && npm run dev`
- [ ] Acessei http://localhost:3000
- [ ] Explorei as 2 jornadas (Tutor / Veterinário)
- [ ] Li ARCHITECTURE.md
- [ ] Consultei DESIGN_SYSTEM.md
- [ ] Explorei a pasta `src/`
- [ ] Pronto para começar! 🚀

---

**Documentação Completa - MVP Phase 1 - Fevereiro 2026**

Próximo: [README.md](README.md) ▶️
