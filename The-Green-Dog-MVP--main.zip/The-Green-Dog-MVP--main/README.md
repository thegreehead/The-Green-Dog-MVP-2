# The Green Dog - MVP Webapp

Plataforma educacional sobre cannabis na medicina veterinária, conectando tutores de pets e médicos veterinários.

## 🚀 Quick Start

### Pré-requisitos
- Node.js 16+ 
- npm ou yarn

### Instalação

```bash
# Instalar dependências
npm install

# Iniciar servidor de desenvolvimento
npm run dev

# Construir para produção
npm run build
```

O app abrirá automaticamente em `http://localhost:3000`

## 📁 Arquitetura de Pastas

```
web/
├── public/                    # Assets estáticos
├── src/
│   ├── components/
│   │   ├── Header.jsx         # Navegação principal (responsive)
│   │   └── Footer.jsx         # Footer com bloco de compliance obrigatório
│   ├── pages/
│   │   ├── Home.jsx           # Página inicial com Hero Section e CTAs duplos
│   │   ├── tutor/
│   │   │   ├── TutorIntro.jsx     # Introdução para tutores
│   │   │   ├── Ebook.jsx          # Landing page do Ebook
│   │   │   └── FindVet.jsx        # Diretório de veterinários (futura)
│   │   └── vet/
│   │       ├── VetIntro.jsx       # Introdução técnica para vets
│   │       ├── Regulation.jsx     # Panorama regulatório (futura)
│   │       ├── Manual.jsx         # Manual de prescrição (futura)
│   │       └── Library.jsx        # Biblioteca científica (futura)
│   ├── styles/
│   │   └── globals.css        # Estilos globais
│   ├── utils/
│   │   └── constants.js       # Constantes e configurações
│   ├── App.jsx                # Componente raiz com roteamento
│   ├── main.jsx               # Entry point
│   └── index.css              # Tailwind imports
├── index.html                 # Template HTML principal
├── package.json
├── tailwind.config.js
├── postcss.config.js
├── vite.config.js
└── .gitignore
```

## 🎯 Features MVP (Fase 1)

### Home
- [x] Hero Section com headline "Qualidade de vida animal começa com informação responsável"
- [x] Dois CTAs principais: "Explorar como Tutor" e "Sou Médico Veterinário"
- [x] Seção de Descoberta (Sintomas e bem-estar)
- [x] Seção de Educação (Ciência e regulação)
- [x] Newsletter CTA
- [x] Trust Indicators

### Navegação
- [x] Header responsivo com logo
- [x] Mobile menu (hamburger)
- [x] Footer com links estruturados
- [x] **Compliance Block** (fixo): "A The Green Dog não prescreve nem comercializa medicamentos. Todo tratamento deve ter acompanhamento veterinário."

### Jornada do Tutor (`/tutor`)
- [x] Página de introdução acolhedora
- [x] Seções sobre dor e bem-estar
- [x] Informações sobre cannabis veterinária (o básico)
- [ ] Landing page com formulário para download do Ebook (próxima fase)
- [ ] Diretório de veterinários (próxima fase)

### Jornada do Veterinário (`/vet`)
- [x] Página de introdução técnica
- [x] Acesso a informações sobre regulação e farmacocinética
- [x] Formulário de cadastro (MVP)
- [ ] Página de Panorama Regulatório - ANVISA/CFMV (próxima fase)
- [ ] Landing do Manual de Prescrição (próxima fase)
- [ ] Biblioteca Científica com filtros (próxima fase)

## 🎨 Design System

### Cores
- **Primary**: Verde (confiança, natureza, saúde) - `#16a34a`
- **Accent**: Ouro/Âmbar (atenção, destaque) - `#f59e0b`
- **Neutral**: Cinza (profissionalismo, limpeza)

### Tipografia
- **Display**: Poppins (Headlines)
- **Body**: Inter (Conteúdo)

### Principles
- Mobile-first responsive design
- Acessibilidade WCAG 2.1 AA
- Sem sensacionalismo - confiável e científico
- Compliance obrigatório em todas as páginas

## 📱 Responsividade

O webapp é mobile-first e totalmente responsivo:
- **Mobile**: 320px - 767px
- **Tablet**: 768px - 1023px
- **Desktop**: 1024px+

Todas as imagens e componentes adaptam-se ao tamanho da tela autmaticamente.

## 🔄 Roteamento

```
/ (Home)
├── /tutor (Layout tutor)
│   ├── /tutor/introducao
│   ├── /tutor/ebook
│   ├── /tutor/faq
│   └── /tutor/veterinarios
│
└── /vet (Layout vet)
    ├── /vet/introducao
    ├── /vet/regulacao
    ├── /vet/manual
    └── /vet/biblioteca
```

## 🔐 Compliance & Segurança

- ⚠️ Bloco de compliance obrigatório em TODAS as páginas (footer)
- Termos de uso e Política de Privacidade (em desenvolvimento)
- Sem prescrição - direcionamento seguro para veterinários
- Sem vendas - educação pura

## 🛠️ Tecnologias

- **Frontend**: React 18
- **Styling**: Tailwind CSS 3
- **Routing**: React Router 6
- **Build**: Vite
- **TypeScript**: (ready para implementar)

## 📊 Próximas Fases

### Fase 2
- Integração com backend (API)
- Autenticação de usuários
- Database de veterinários
- Sistema de capturas de email

### Fase 3
- Biblioteca Científica completa com busca
- Área exclusiva para veterinários
- Certificação e trilhas de conhecimento
- Mobile app nativo

## 📞 Contato

Para sugestões ou dúvidas, abra uma issue ou entre em contato via:
- Email: contact@thegreendogvet.com
- Website: www.thegreendogvet.com

---

**Desenvolvido com ❤️ por The Green Dog Team**
