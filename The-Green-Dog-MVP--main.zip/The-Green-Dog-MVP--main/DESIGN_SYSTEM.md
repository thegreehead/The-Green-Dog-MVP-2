/**
 * Design System Reference - The Green Dog
 * Guia de cores, tipografia e componentes
 */

# 🎨 DESIGN SYSTEM

## Cores

### Primary (Tutores)
- Hex: #16a34a
- RGB: 22, 163, 74
- HSL: 142°, 76%, 36%
- Uso: CTAs tutores, headers de seções, destaque

### Accent (Veterinários)
- Hex: #f59e0b
- RGB: 245, 158, 11
- HSL: 38°, 92%, 50%
- Uso: CTAs vet, avisos, destaque técnico

### Compliance (Obrigatório)
- Hex: #15803d (Verde escuro)
- Uso: Fundo do bloco de compliance no footer
- Sempre com texto branco

### Neutral (Confiança, Profissionalismo)
- Cinza 50: #f9fafb (backgrounds claros)
- Cinza 100: #f3f4f6
- Cinza 400: #9ca3af (texto secundário)
- Cinza 900: #111827 (texto principal/backgrounds escuros)

## Tipografia

### Display (Headlines)
- Font: Poppins, sans-serif
- Weights: 600, 700, 800
- Sizes: H1 (48px+), H2 (36px), H3 (24px), H4 (20px)
- Uso: Títulos, seções, CTAs principais

### Body (Conteúdo)
- Font: Inter, system-ui, sans-serif
- Weights: 400 (regular), 500 (medium), 600 (semibold), 700 (bold)
- Sizes: 16px (base), 14px (small), 18px (large)
- Line-height: 1.6 (conforto de leitura)

## Componentes Principais

### Button (CTA)
```
PRIMARY: Verde #16a34a, branco texto
SECONDARY: Branco bg, verde border
ACCENT: Dourado #f59e0b, cinza escuro texto
SIZES: Small (px-4 py-2), Medium (px-6 py-3), Large (px-8 py-4)
```

### Card
```
Background: Branco #ffffff
Border: Cinza 200 (#e5e7eb) ou leve sombra
Padding: 24px (1.5rem)
Border-radius: 8px
Hover: Sombra aumentada (shadow-lg)
```

### Input/Textarea
```
Border: Cinza 300 (#d1d5db)
Focus: Border verde primary, anel de foco
Padding: 12px
Border-radius: 8px
Font: Inter, 16px
```

### Navigation (Header)
```
Height: 64px (h-16)
Background: Branco #ffffff com sombra
Links: Cinza 600 padrão, verde 600 no hover
Mobile: Hamburger em < 768px
```

### Footer
```
Background: Cinza escuro #111827
Text: Branco
Compliance block: Verde escuro #15803d com branco
Links: Cinza 400 padrão, primário 400 no hover
```

### Forms (Captura de Leads)
```
Label: Poppins, semibold, cinza 900
Input: 100% width, border cinza
Help text: Cinza 500, 12px
Success state: Border verde
Error state: Border vermelho (#dc2626)
```

## Espaçamento

```
Tipicamente: 4px (0.25rem), 8px (0.5rem), 16px (1rem), 24px (1.5rem), 32px (2rem), 48px (3rem)
Seções: 64px (4rem) verticalmente
Containers: Max-width 7xl (80rem)
```

## Sombras

```
Padrão (hover): shadow-md (0 4px 6px -1px rgba(0,0,0,0.1))
Forte (modals): shadow-lg (0 10px 15px -3px rgba(0,0,0,0.1))
Suave: shadow-sm (0 1px 2px 0 rgba(0,0,0,0.05))
```

## Acessibilidade

- Contrast ratio mínima: 4.5:1 para texto normal
- Texto em botões: Sempre legível
- Estados (hover, focus): Sempre visíveis
- Ícones: Sempre com labels ou ARIA

## Responsividade

```
Mobile: < 640px (base)
SM: ≥ 640px
MD: ≥ 768px
LG: ≥ 1024px
XL: ≥ 1280px
2XL: ≥ 1536px
```

## Exemplos de Componentes

### Hero Section
```
BG: Gradient (primary-50 → white)
Padding: 80-128px vertical (mobile: 64px)
Text: Centralizado
CTA: Dual buttons (tutor | vet)
```

### Card Section
```
Grid: 1 coluna (mobile), 2-3 (desktop)
Cards: 6 uniformes com hover effect
Ícone: 48-64px emoji/SVG
```

### Newsletter CTA
```
BG: Primary green (#16a34a)
Text: Branco
Input: Branco com padding
Button: Accent dourado (#f59e0b)
Layout: Flexbox responsivo
```

### Compliance Block
```
BG: Verde escuro (#15803d)
Text: Branco, semibold, 14px
Icon: ⚠️ 
Padding: 16px
Sempre visível (fixed position no footer)
```

## Dark Mode (Futura)

```
Primary: #4ade80 (verde mais claro)
Backgrounds: #0f172a (cinza muito escuro)
Text: #f1f5f9 (branco suave)
```
