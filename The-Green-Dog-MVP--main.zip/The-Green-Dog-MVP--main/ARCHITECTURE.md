# 📐 Arquitetura Técnica - The Green Dog MVP

## Visão Geral do Projeto

The Green Dog é uma plataforma educacional (webapp) que conecta **Tutores de Pets** e **Médicos Veterinários** em torno de educação responsável sobre cannabis na medicina veterinária.

### Dois Fluxos de Jornada Distintos

```
┌─────────────────────────────────────────────────────────────┐
│                        HOME                                  │
│   "Qualidade de vida animal começa com informação..."       │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────┐    ┌──────────────────────┐       │
│  │  Sou Tutor           │    │  Sou Veterinário     │       │
│  │  🐾 Acolhedor        │    │  🔬 Técnico           │       │
│  │  Foco: Qualidade vida│    │  Foco: Segurança      │       │
│  │  Tom: Empático       │    │  Tom: Científico      │       │
│  └──────────────────────┘    └──────────────────────┘       │
│           ↓                            ↓                     │
│      /tutor/**                      /vet/**                 │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## Estrutura de Componentes

### Layout Principal

```
┌─────────────────────────────────────────────┐
│            HEADER (Fixo)                    │  components/Header.jsx
├─────────────────────────────────────────────┤
│                                              │
│         PAGES / ROUTE RENDERING             │  pages/**/*.jsx
│                                              │
│         (Conteúdo Dinâmico)                 │
│                                              │
├─────────────────────────────────────────────┤
│   FOOTER + COMPLIANCE BLOCK (Fixo)          │  components/Footer.jsx
│                                              │
│  ⚠️ "A Green Dog não prescreve nem         │
│     comercializa. Todo tratamento deve      │
│     ter acompanhamento veterinário."        │
├─────────────────────────────────────────────┘
```

### Componente: Header

**Arquivo**: `src/components/Header.jsx`

```jsx
Features:
- Logo + Brand name
- Navegação principal (responsiva)
- Mobile menu (hamburger icon)
- Links de navegação: Início, Sobre, Contato
- Indicador ativo (highlight da página atual)
```

**Responsividade**:
- Desktop: Menu horizontal inline
- Mobile (< 768px): Menu colapsável (hamburger)

### Componente: Footer

**Arquivo**: `src/components/Footer.jsx`

```jsx
Features:
- COMPLIANCE BLOCK (verde, destaque, fixo)
  Mensagem: "A The Green Dog não prescreve..."
  
- Main Footer Content:
  ├── Brand/Logo
  ├── Links para Tutores
  ├── Links para Veterinários
  ├── Links Legais
  └── Redes Sociais (placeholder)
```

**Importância**: 
⚠️ O compliance é obrigatório em TODAS as páginas. Fica visível acima do footer.

## Arquitetura de Páginas (Pages)

### 1. Home (`src/pages/Home.jsx`)

**Estrutura**:
```
├── Hero Section
│   └── Headline + Subheading
│       └── Dois CTAs (Tutor | Vet)
│
├── Discovery Section
│   └── 3 Cards (Entenda a Dor, Cannabis Vet, Qualidade de Vida)
│
├── Education Section
│   ├── Card: Biblioteca Científica
│   └── Card: Regulação Atualizada
│
├── Newsletter CTA
│   └── Email Input + Subscribe
│
└── Trust Indicators
    └── Stats (100% Ciência, 0 Conflitos, etc)
```

**CTAs Duais**: 
- Tutor: Tom acolhedor, verde, "Explorar como Tutor"
- Vet: Tom técnico, dourado, "Sou Médico Veterinário"

### 2. Tutores - Jornada `/tutor/**`

#### 2.1 Introdução (`src/pages/tutor/TutorIntro.jsx`)
```
├── Hero: Bem-vindo acolhedor
├── Módulo 1: Entenda a Dor (💭)
├── Módulo 2: Cannabis Vet (🌿)
├── CTA: Download Ebook
│   └── Formulário (Email, Nome Pet)
├── FAQ Section
│   ├── "Pode ter overdose?"
│   ├── "É legal?"
│   └── "Como encontro vet?"
└── CTA: Encontrar Veterinário
```

#### 2.2 Ebook Landing (futura)
```
├── Apresentação do guide
├── Benefícios listados
├── Depoimentos (se houver)
└── Formulário de capture
```

#### 2.3 Diretório de Veterinários (futura)
```
├── Busca/filtros
├── Lista de veterinários
└── Agendamento direto (integração)
```

### 3. Veterinários - Jornada `/vet/**`

#### 3.1 Introdução (`src/pages/vet/VetIntro.jsx`)
```
├── Hero: Bem-vindo técnico
├── Módulo 1: Regulação & Compliance (⚖️)
├── Módulo 2: Farmacocinética (📊)
├── CTA: Download Manual
│   └── Formulário com verificação (Email, Nome, CRMV)
├── Biblioteca Científica preview
│   └── Filtros (Espécie, Indicação, Tipo Evidência)
└── CTA: Acessar biblioteca completa
```

#### 3.2 Regulação (futura)
```
├── Timeline regulatório Brasil
├── Regras ANVISA
├── Regras CFMV
└── Boas práticas internacionais
```

#### 3.3 Manual de Prescrição (futura)
```
├── Protocolos por espécie
├── Dosagem guidelines
├── Farmocin ética
├── COA interpretation
└── Case studies
```

#### 3.4 Biblioteca Científica (futura)
```
├── Search + Advanced Filters
│   ├── Espécie (Canino, Felino, Equino...)
│   ├── Indicação (Dor, Epilepsia, Inflamação...)
│   └── Tipo Evidência (RCT, Observacional...)
├── Resultados (limitados no MVP)
└── Detalhes artigo (com COA requirements)
```

## Sistema de Roteamento

**Framework**: React Router v6

```javascript
// src/App.jsx
<Routes>
  <Route path="/" element={<Home />} />
  <Route path="/tutor/*" element={<TutorIntro />} />
  <Route path="/vet/*" element={<VetIntro />} />
  
  // Futuras rotas:
  // <Route path="/tutor/ebook" element={<EbookLanding />} />
  // <Route path="/vet/biblioteca" element={<ScientificLibrary />} />
  // etc.
</Routes>
```

## Design System (Tailwind Config)

### Palette

```javascript
colors: {
  primary: {
    50: "#f0fdf4",
    600: "#16a34a",    // Verde principal
    900: "#145231"
  },
  accent: {
    500: "#f59e0b",    // Ouro/Âmbar (veterinários)
    700: "#b45309"
  },
  neutral: {
    50: "#f9fafb",
    900: "#111827"
  }
}
```

### Tipografia

```javascript
fontFamily: {
  sans: "Inter",       // Body text
  display: "Poppins"   // Headlines
}
```

## Fluxo de Dados & Estado

### MVP (Sem Backend)

Estado estático em componentes. Formulários captura email no console.

### Fase 2 (Com Backend)

```
[React Components] 
    ↕️ (API Calls)
[Backend API]
    ↕️ (GraphQL/REST)
[Database]
```

Endpoints necessários:
- POST `/api/capture/tutor` (Newsletter + Ebook)
- POST `/api/capture/vet` (Manual + Cadastro)
- GET `/api/vets` (Diretório de veterinários)
- GET `/api/articles` (Biblioteca científica)

## Compliance & Segurança

### ✅ MVP Compliance

1. **Bloco Fixo em Todas as Páginas** (Footer)
   - Mensagem obrigatória sobre não prescrição
   - Destaque visual (fundo verde)

2. **Sem Prescrição Direta**
   - Links diretos para veterinários
   - FAQ ressaltam necessidade de profissional

3. **Sem Vendas/E-commerce**
   - Apenas capturas educacionais
   - Direcionamento a profissionais

### 🔒 Próximas Fases

- Termos de Uso detalhados
- Política de Privacidade LGPD compliant
- Verificação de veterinários (CRMV API)
- Consentimento informado

## Responsividade & Acessibilidade

### Mobile-First Approach

```css
/* Default: Mobile (320px+) */
.container { padding: 1rem; }

/* Tablet (768px+) */
@media (min-width: 768px) { ... }

/* Desktop (1024px+) */
@media (min-width: 1024px) { ... }
```

### Acessibilidade

- Contrast ratio 4.5:1 para texto
- Semantic HTML (`<button>`, `<form>`, `<nav>`)
- ARIA labels onde necessário
- Keyboard navigation

## Performance

- **Vite** para build otimizado
- **Tailwind** para CSS purificado
- Code splitting automático com React Router
- Imagens otimizadas (futura)

## Estrutura de Pastas Detalhada

```
web/
├── public/                          # Assets estáticos
│   ├── favicon.svg
│   └── favicon.ico
│
├── src/
│   ├── components/
│   │   ├── Header.jsx              # Navegação
│   │   └── Footer.jsx              # Footer + Compliance
│   │
│   ├── pages/
│   │   ├── Home.jsx                # Home page
│   │   ├── tutor/
│   │   │   ├── TutorIntro.jsx      # /tutor
│   │   │   ├── Ebook.jsx           # /tutor/ebook (futura)
│   │   │   └── FindVet.jsx         # /tutor/veterinarios (futura)
│   │   └── vet/
│   │       ├── VetIntro.jsx        # /vet
│   │       ├── Regulation.jsx      # /vet/regulacao (futura)
│   │       ├── Manual.jsx          # /vet/manual (futura)
│   │       └── Library.jsx         # /vet/biblioteca (futura)
│   │
│   ├── styles/
│   │   └── globals.css             # Tailwind + custom
│   │
│   ├── utils/
│   │   ├── constants.js            # Constantes globais
│   │   └── helpers.js              # Funções utilitárias
│   │
│   ├── App.jsx                     # Root component + router
│   ├── main.jsx                    # Vite entry point
│   └── index.css                   # Tailwind directives
│
├── index.html                      # HTML template
├── package.json                    # Dependencies
├── tailwind.config.js              # Tailwind config
├── postcss.config.js               # PostCSS config
├── vite.config.js                  # Vite config
├── .gitignore
├── README.md                       # Este arquivo
└── ARCHITECTURE.md                 # Documentação técnica
```

## Desenvolvimento

### Setup Local

```bash
npm install
npm run dev
```

### Build para Produção

```bash
npm run build
npm run preview
```

### Comandos Disponíveis

```bash
npm run dev      # Dev server (localhost:3000)
npm run build    # Production build
npm run preview  # Preview production build
npm run lint     # Lint code (futura)
```

---

**Documentação criada para MVP Phase 1 - Fevereiro 2026**
