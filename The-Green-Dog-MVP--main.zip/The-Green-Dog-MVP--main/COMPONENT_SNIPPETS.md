/**
 * Componentes Reutilizáveis - The Green Dog
 * Snippets for common patterns
 */

// ============ BUTTON ============
/*
import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'accent';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  type?: 'button' | 'submit' | 'reset';
  [key: string]: any;
}

export default function Button({ 
  children, 
  variant = 'primary', 
  size = 'md',
  className = '',
  ...props 
}: ButtonProps) {
  const baseClasses = 'font-semibold rounded-lg transition-colors focus:outline-none focus:ring-2';
  
  const variants = {
    primary: 'bg-primary-600 text-white hover:bg-primary-700 focus:ring-primary-300',
    secondary: 'border-2 border-primary-600 text-primary-600 hover:bg-primary-50 focus:ring-primary-300',
    accent: 'bg-accent-500 text-neutral-900 hover:bg-accent-600 focus:ring-accent-300',
  };
  
  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg',
  };
  
  return (
    <button 
      className={`${baseClasses} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}

// USO:
// <Button>Click me</Button>
// <Button variant="accent" size="lg">Download</Button>
// <Button variant="secondary" type="submit">Submit</Button>
*/

// ============ CARD ============
/*
interface CardProps {
  children: React.ReactNode;
  className?: string;
  hoverable?: boolean;
  variant?: 'default' | 'accent' | 'highlight';
}

export default function Card({ 
  children, 
  className = '', 
  hoverable = false,
  variant = 'default'
}: CardProps) {
  const variants = {
    default: 'bg-white border border-neutral-200',
    accent: 'bg-accent-50 border border-accent-200',
    highlight: 'bg-primary-50 border-l-4 border-l-primary-600',
  };
  
  return (
    <div 
      className={`rounded-lg p-6 ${variants[variant]} ${hoverable ? 'hover:shadow-lg transition-shadow' : ''} ${className}`}
    >
      {children}
    </div>
  );
}

// USO:
// <Card><h2>Title</h2><p>Content</p></Card>
// <Card hoverable variant="accent">Hover me</Card>
*/

// ============ FORM INPUT ============
/*
interface InputProps {
  label?: string;
  error?: string;
  type?: string;
  placeholder?: string;
  className?: string;
  [key: string]: any;
}

export default function Input({ 
  label, 
  error, 
  type = 'text', 
  className = '',
  ...props 
}: InputProps) {
  return (
    <div className="mb-4">
      {label && (
        <label className="block text-sm font-semibold text-neutral-900 mb-2">
          {label}
        </label>
      )}
      <input
        type={type}
        className={`w-full px-4 py-3 rounded-lg border ${
          error ? 'border-red-500' : 'border-neutral-300'
        } focus:outline-none focus:border-primary-600 focus:ring-2 focus:ring-primary-300/50 ${className}`}
        {...props}
      />
      {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
    </div>
  );
}

// USO:
// <Input label="Email" type="email" placeholder="você@email.com" />
// <Input label="Password" type="password" error="Senha inválida" />
*/

// ============ HERO SECTION ============
/*
interface HeroProps {
  headline: string;
  subheading?: string;
  cta?: React.ReactNode;
  image?: string;
  background?: 'primary' | 'accent' | 'neutral';
}

export default function Hero({
  headline,
  subheading,
  cta,
  image,
  background = 'primary'
}: HeroProps) {
  const bgStyles = {
    primary: 'bg-gradient-to-br from-primary-50 via-white to-neutral-50',
    accent: 'bg-gradient-to-br from-accent-50 to-white',
    neutral: 'bg-gradient-to-br from-neutral-50 to-white',
  };
  
  return (
    <section className={`${bgStyles[background]} py-20 sm:py-32 px-4 sm:px-6 lg:px-8`}>
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6 font-display leading-tight">
          {headline}
        </h1>
        {subheading && (
          <p className="text-lg sm:text-xl text-neutral-600 mb-12 max-w-2xl mx-auto leading-relaxed">
            {subheading}
          </p>
        )}
        {cta && <div className="flex justify-center">{cta}</div>}
      </div>
    </section>
  );
}

// USO:
// <Hero 
//   headline="Welcome"
//   subheading="Learn more about..."
//   cta={<Button>Get Started</Button>}
// />
*/

// ============ COMPLIANCE BLOCK ============
/*
export default function ComplianceBlock() {
  return (
    <div className="bg-primary-700 py-4 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <p className="text-sm text-center font-semibold text-white leading-relaxed">
          ⚠️ A The Green Dog não prescreve nem comercializa medicamentos. 
          Todo tratamento deve ter acompanhamento veterinário.
        </p>
      </div>
    </div>
  );
}

// USO: Coloque no Footer
*/

// ============ GRID LAYOUT ============
/*
export default function GridCards({ items, cols = 3 }) {
  return (
    <div className={`grid grid-cols-1 md:grid-cols-${cols === 2 ? '2' : '3'} gap-6`}>
      {items.map((item) => (
        <Card key={item.id} hoverable>
          <div className="text-4xl mb-4">{item.icon}</div>
          <h3 className="text-xl font-bold text-neutral-900 mb-3">{item.title}</h3>
          <p className="text-neutral-600">{item.description}</p>
        </Card>
      ))}
    </div>
  );
}

// USO:
// const items = [{ id: 1, icon: '🐾', title: 'Title', description: 'Desc' }];
// <GridCards items={items} cols={3} />
*/

// ============ MODAL/DIALOG ============
/*
interface ModalProps {
  isOpen: boolean;
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  actions?: React.ReactNode;
}

export default function Modal({ 
  isOpen, 
  title, 
  children, 
  onClose, 
  actions 
}: ModalProps) {
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
        <h2 className="text-2xl font-bold text-neutral-900 mb-4">{title}</h2>
        <div className="mb-6">{children}</div>
        <div className="flex justify-end gap-3">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          {actions}
        </div>
      </div>
    </div>
  );
}

// USO:
// const [isOpen, setIsOpen] = useState(false);
// <Modal isOpen={isOpen} title="Title" onClose={() => setIsOpen(false)}>
//   Conteúdo
// </Modal>
*/

// ============ TABS ============
/*
interface Tab {
  label: string;
  content: React.ReactNode;
}

interface TabsProps {
  tabs: Tab[];
}

export default function Tabs({ tabs }: TabsProps) {
  const [activeTab, setActiveTab] = useState(0);
  
  return (
    <div>
      <div className="flex border-b border-neutral-200 mb-6">
        {tabs.map((tab, idx) => (
          <button
            key={idx}
            onClick={() => setActiveTab(idx)}
            className={`px-6 py-3 font-medium transition-colors ${
              activeTab === idx
                ? 'border-b-2 border-primary-600 text-primary-600'
                : 'text-neutral-600 hover:text-primary-600'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div>{tabs[activeTab].content}</div>
    </div>
  );
}

// USO:
// <Tabs tabs={[
//   { label: 'Tab 1', content: <div>Content 1</div> },
//   { label: 'Tab 2', content: <div>Content 2</div> },
// ]} />
*/

// ============ ACCORDION ============
/*
interface AccordionItem {
  title: string;
  content: React.ReactNode;
}

export default function Accordion({ items }: { items: AccordionItem[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  
  return (
    <div className="space-y-3">
      {items.map((item, idx) => (
        <div key={idx} className="border border-neutral-200 rounded-lg">
          <button
            onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
            className="w-full px-6 py-4 text-left font-semibold text-neutral-900 hover:bg-neutral-50 flex justify-between items-center"
          >
            {item.title}
            <span className={`transform transition-transform ${openIndex === idx ? 'rotate-180' : ''}`}>
              ▼
            </span>
          </button>
          {openIndex === idx && (
            <div className="px-6 py-4 border-t border-neutral-200 text-neutral-600">
              {item.content}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// USO:
// <Accordion items={[
//   { title: 'Question', content: <p>Answer</p> },
// ]} />
*/

export {};
