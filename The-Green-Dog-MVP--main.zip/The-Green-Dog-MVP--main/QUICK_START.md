# 🚀 GUIA RÁPIDO - The Green Dog MVP

## ✅ O que já está implementado (MVP Phase 1)

### Estrutura Base
- [x] Pasta structure completa
- [x] Configuração Vite + React 18
- [x] Tailwind CSS com tema customizado
- [x] React Router v6 configurado

### Componentes Principais
- [x] **Header**: Navegação responsiva com mobile menu
- [x] **Footer**: Links estruturados + Bloco de Compliance obrigatório
- [x] **Home**: Hero Section, Discovery, Education, Newsletter, Trust Indicators

### Jornadas
- [x] **Tutor (/tutor)**: Página de introdução com FAQ e CTA de Ebook
- [x] **Veterinário (/vet)**: Página técnica com forms e preview da biblioteca

### Documentação
- [x] README.md - Setup e overview
- [x] ARCHITECTURE.md - Design técnico detalhado
- [x] DESIGN_SYSTEM.md - Referência de cores/tipografia/componentes
- [x] constants.js - Constantes globais e conteúdo

---

## 📋 Próximas Fases (Roadmap)

### Fase 2: Integração com Backend (2-3 semanas)
```
TAREFAS:
- [ ] Setup API backend (Node/Express ou similar)
- [ ] Implementar endpoints de captura:
    - POST /api/capture/tutor (email, pet name, newsletter)
    - POST /api/capture/vet (email, nome, CRMV, manual)
- [ ] Setup Database (PostgreSQL/MongoDB)
- [ ] Conectar formulários do Frontend aos endpoints
- [ ] Verificação de CRMV com API pública
- [ ] Envio de emails (Mailgun/SendGrid)
```

### Fase 3: Conteúdo & Páginas Secundárias (3-4 semanas)
```
PÁGINAS A CRIAR:
- [ ] /tutor/ebook - Landing page do guia completo
- [ ] /tutor/veterinarios - Diretório + busca de vets
- [ ] /vet/regulacao - Panorama regulatório (ANVISA, CFMV)
- [ ] /vet/manual - Manual de prescrição com protocolos
- [ ] /vet/biblioteca - Biblioteca científica com busca + filtros
- [ ] /sobre - Página institucional (missão, visão, valores)
- [ ] /politica-privacidade - LGPD compliant
- [ ] /termos-uso - Terms of service
```

### Fase 4: Área Restrita para Veterinários (3-4 semanas)
```
FEATURES:
- [ ] Sistema de autenticação (JWT + cookies)
- [ ] Dashboard para vets registrados
- [ ] Acesso exclusivo a conteúdo premium
- [ ] Certificação de cursos/trilhas de conhecimento
- [ ] Perfil profissional customizável
```

### Fase 5: Mobile App Nativa (Futura)
```
- [ ] React Native para iOS/Android
- [ ] Offline-first capabilidades
- [ ] Push notifications
- [ ] Camera integration (para scans de COA)
```

---

## 🎯 Como Trabalhar com o Projeto

### 1️⃣ Setup Local

```bash
# Clone ou abra o projeto
cd web

# Instale dependências
npm install

# Inicie servidor de dev
npm run dev

# Abrirá em localhost:3000
```

### 2️⃣ Estrutura de Pastas ao Adicionar Conteúdo

**Para nova página (ex: Tutores - Ebook)**

```
src/pages/tutor/
  ├── TutorIntro.jsx    (✓ Já existe)
  ├── Ebook.jsx         (← NOVA)
  └── FindVet.jsx       (← NOVA)
```

**Passo a passo:**

1. Crie arquivo em `src/pages/[categoria]/NovaPagina.jsx`
2. Importe em `App.jsx` e adicione rota:
   ```jsx
   <Route path="/caminho/novo" element={<NovaPagina />} />
   ```
3. Use componentes do design system (cores, typography, buttons)
4. Teste responsividade em mobile (DevTools)

### 3️⃣ Adicionar Formulário de Captura

**Template** (reutilizável):

```jsx
// src/components/LeadCaptureForm.jsx
export default function LeadCaptureForm({ onSubmit, fields }) {
  const [formData, setFormData] = useState({});
  
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Lead captured:', formData);
    // Futura: chamar API
    onSubmit(formData);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* mapped fields */}
    </form>
  );
}
```

### 4️⃣ Adicionar Novo Filtro à Biblioteca Científica

**Em `constants.js`:**

```javascript
export const FILTER_OPTIONS = {
  // ... existing filters
  NEW_FILTER: [
    { value: 'all', label: 'Todos' },
    { value: 'option1', label: 'Opção 1' },
  ]
}
```

**Em `Library.jsx`:**

```jsx
<select className="...">
  {FILTER_OPTIONS.NEW_FILTER.map(opt => (
    <option key={opt.value} value={opt.value}>
      {opt.label}
    </option>
  ))}
</select>
```

---

## 🔧 Ferramentas & Stack

### Frontend
- React 18
- Tailwind CSS 3
- React Router 6
- Vite

### DevTools Recomendados
- VS Code com extensões:
  - Tailwind CSS IntelliSense
  - ES7+ React/Redux/React-Native snippets
  - Prettier

### Testing (Futuro)
- Vitest (para unit tests)
- React Testing Library
- Cypress (e2e)

### Backend (Futuro)
- Node.js + Express
- PostgreSQL / MongoDB
- JWT para auth
- Nodemailer para emails

---

## 📊 KPIs & Métricas para Monitorar

```
Tutores:
- Email captures (formulário de ebook)
- CTR em "Encontrar Veterinário"
- Tempo em página

Veterinários:
- Registros (CRMV verificados)
- Acesso à biblioteca
- Engajement com conteúdo técnico

Geral:
- Page views por rota
- Bounce rate
- Conversões por funnel
```

---

## 🚨 Compliance Checklist

- [x] Bloco de compliance visível em todas as páginas ✓
- [ ] Termos de Uso página (em Fase 2)
- [ ] Política de Privacidade LGPD (em Fase 2)
- [ ] Verificação de CRMV antes de liberar acesso (em Fase 4)
- [ ] Disclaimer em artigos científicos (em Fase 3)
- [ ] Sem prescrição direta - apenas direcionamento (✓ Mantido)
- [ ] Sem e-commerce / vendas (✓ Mantido)

---

## 💡 Dicas de Desenvolvimento

### Mobile-First
Sempre design para mobile primeiro, depois expanda para desktop.

```jsx
// ❌ ERRADO
<div className="hidden md:block">Desktop only</div>

// ✅ CERTO
<div className="block md:hidden">Mobile</div>
<div className="hidden md:block">Desktop</div>
```

### Acessibilidade
- Use `<button>` ao invés de `<div onClick>`
- Sempre tenha labels associados em inputs
- Mantenha contrast ratio 4.5:1 mínimo

### Performance
- Lazy load images (futura)
- Code splitting automático com React Router
- Minimize bundles com Tree Shaking

### Estado Global (Futuro)
Quando precisar, use Context API:

```jsx
// src/context/AuthContext.jsx
export const AuthContext = createContext();

// src/provider/AuthProvider.jsx
export default function AuthProvider({ children }) {
  // logic here
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}
```

---

## 🔐 Secrets & Environment Variables

Crie arquivo `.env.local` (gitignored):

```
VITE_API_URL=http://localhost:3001
VITE_ENV=development
```

Acesse em código:

```javascript
const API_URL = import.meta.env.VITE_API_URL;
```

---

## 📞 Contato & Suporte

- Email: contact@thegreendogvet.com
- Issues: [GitHub repository]
- Team: The Green Dog Development Team

---

**Última atualização: Fevereiro 2026 - MVP Phase 1 ✅**
