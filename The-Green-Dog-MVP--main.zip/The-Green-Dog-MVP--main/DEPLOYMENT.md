# 🚀 Guia de Deployment - The Green Dog

## 1️⃣ Build para Produção

### Local Build Test

```bash
# Build otimizado
npm run build

# Visualizar build localmente
npm run preview
```

### Output
```
dist/
├── index.html
├── assets/
│   ├── index-{hash}.js
│   ├── index-{hash}.css
│   └── [outras imagens/fonts]
```

---

## 2️⃣ Deploy em Hosts Principais

### 🟦 Vercel (RECOMENDADO para MVP)

```bash
# 1. Instale Vercel CLI
npm i -g vercel

# 2. Deploy
vercel

# 3. Siga as instruções
```

**Vantagens:**
- Deploy automático a cada push (Git integration)
- SSL gratuito
- CDN global
- Preview URLs para PRs
- Muito usado para Vite + React

**Arquivo `vercel.json` (opcional):**
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist"
}
```

---

### 🟦 Netlify

```bash
# 1. Instale Netlify CLI
npm i -g netlify-cli

# 2. Deploy
netlify deploy

# 3. Ou conecte seu GitHub
# Acesse netlify.com, click "New site from Git"
```

**Instruções diretas:**
- Build command: `npm run build`
- Publish directory: `dist`

---

### 🟦 AWS S3 + CloudFront

```bash
# 1. Build
npm run build

# 2. Suba para S3
aws s3 sync dist/ s3://your-bucket-name --delete

# 3. Invalide cache CloudFront
aws cloudfront create-invalidation \
  --distribution-id YOUR_DISTRIBUTION_ID \
  --paths "/*"
```

**Setup AWS:**
- Criar S3 bucket com website hosting ativo
- Criar CloudFront distribution
- Configurar domain com Route53

---

### 🟦 Google Firebase

```bash
# 1. Instale Firebase CLI
npm i -g firebase-tools

# 2. Login
firebase login

# 3. Init projeto
firebase init hosting

# 4. Deploy
firebase deploy
```

**firebase.json:**
```json
{
  "hosting": {
    "public": "dist",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
    "rewrites": [{
      "source": "**",
      "destination": "/index.html"
    }]
  }
}
```

---

## 3️⃣ Configurações de Produção

### Environment Variables

Crie `.env.production`:
```
VITE_API_URL=https://api.thegreendogvet.com
VITE_ENV=production
```

### Headers de Segurança (Recomendado)

Adicione ao seu host:
```
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
```

### Redirecionamento 404 para SPA

Configurar servidor para redirecionar 404s para `index.html`:

**Vercel**: Automático ✓

**Netlify**: Automático para SPAs ✓

**AWS S3**: Configure error page para `index.html`

**Firebase**: Reescrita automática ✓

---

## 4️⃣ Performance & Otimização

### Lighthouse Score Target

| Métrica | Target |
|---------|--------|
| Performance | > 90 |
| Accessibility | > 95 |
| Best Practices | > 90 |
| SEO | > 95 |

### Checklist de Performance

- [x] Minificação JS/CSS via Vite
- [x] Tree shaking (dependências não usadas)
- [ ] Lazy loading de imagens (add depois)
- [ ] Code splitting por rota (React Router)
- [ ] Gzip/Brotli compression
- [ ] Cache headers

### Verificar Performance

```bash
# Lighthouse local
npm run build
npm run preview
# Abrir DevTools > Lighthouse > Audit
```

---

## 5️⃣ Monitoramento & Analytics

### Google Analytics 4

```html
<!-- Adicione no head do index.html -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### Sentry (Error Tracking)

```bash
npm install @sentry/react @sentry/tracing
```

```jsx
// src/main.jsx
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "YOUR_SENTRY_DSN",
  environment: process.env.VITE_ENV,
  tracesSampleRate: 1.0,
});
```

### Uptime Monitoring

Recomendações:
- UptimeRobot (free)
- StatusPage.io
- Pingdom

---

## 6️⃣ CI/CD Pipeline

### GitHub Actions (automático)

Crie `.github/workflows/deploy.yml`:

```yaml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - run: npm install
      
      - run: npm run build
      
      - name: Deploy to Vercel
        run: npm install -g vercel && vercel --prod --token ${{ secrets.VERCEL_TOKEN }}
```

### GitLab CI

Crie `.gitlab-ci.yml`:

```yaml
stages:
  - build
  - deploy

build:
  stage: build
  script:
    - npm install
    - npm run build
  artifacts:
    paths:
      - dist/

deploy_prod:
  stage: deploy
  script:
    - npm install -g vercel
    - vercel --prod --token $VERCEL_TOKEN
  only:
    - main
```

---

## 7️⃣ Rollback & Versioning

### Git Tags

```bash
# Tag uma release
git tag -a v1.0.0 -m "MVP Release"
git push origin v1.0.0

# Ver releases
git tag -l
git show v1.0.0
```

### Vercel Deployments

Vercel mantém histórico. Para rollback:
1. Acesse vercel.com/project/deployments
2. Clique em qualquer deploy anterior
3. Clique "Promote to Production"

---

## 8️⃣ Domain & SSL

### Conectar Domain

**Vercel:**
1. Vá em Project Settings > Domains
2. Adicione seu domain
3. Configure DNS records conforme instruído

**Netlify:**
1. Vá em Site settings > Domain management
2. Adicione custom domain

### SSL (Automático)

Todos os hosts principais oferecem SSL grátis via Let's Encrypt ✓

---

## 9️⃣ Backup & Disaster Recovery

### Estratégia

1. **Code**: GitHub (default ✓)
2. **Database**: (Fase 2) Backups automáticos do provider
3. **Media**: (Fase 3) S3 com versionamento

### Checklist

- [x] Repositório Git privado
- [ ] Backup diário do banco (Fase 2)
- [ ] Documentação de procedimentos
- [ ] Plano de recuperação testado

---

## 🔟 Pre-Launch Checklist

### Técnico

- [ ] Build sem erros: `npm run build`
- [ ] Lighthouse > 90 em 3 métri cas
- [ ] Mobile responsiven ess testado
- [ ] Compliance block em todas as páginas
- [ ] 404s redirecionam para home
- [ ] Links internos funcionam
- [ ] Formulários enviam dados (console log OK)
- [ ] Site funciona offline (PWA - futura)

### Conteúdo

- [ ] Copy revisado (sem typos)
- [ ] Imagens otimizadas
- [ ] Meta descriptions preenchidas
- [ ] Open Graph tags configuradas

### SEO

- [ ] Sitemap.xml criado
- [ ] Robots.txt configurado
- [ ] Canonical tags em páginas
- [ ] Google Search Console vinculado
- [ ] Google Analytics conectado

### Compliance

- [ ] Compliance block visível
- [ ] Política de Privacidade presente
- [ ] Termos de Uso presentes
- [ ] Cookies consent (se necessário)
- [ ] GDPR/LGPD compliant

### Segurança

- [ ] HTTPS enabled
- [ ] Security headers configurados
- [ ] Sem secrets no repo (.env.local)
- [ ] Dependencies auditadas: `npm audit`

---

## 🎯 Próximos Passos Pós-Deploy

1. Monitorar Sentry/Errors por 48h
2. Verificar Google Analytics
3. Enviar links para beta testers
4. Coletar feedback
5. Fazer correções conforme necessário

---

## 📞 Troubleshooting

### Build falha
```bash
# Limpar cache
rm -rf node_modules dist
npm install
npm run build
```

### Site não atualiza
```bash
# Limpar cache host
# Vercel: Automático após novo push
# Netlify: Settings > Clear cache and deploy
# Seu próprio server: CTRL+F5 no browser
```

### Deploy com erros
1. Verifique env vars
2. Verifique console.log / npm run preview
3. Veja logs do host
4. Rollback para versão anterior

---

## 🏆 Recomendação Final

**Para MVP: USE VERCEL**

- Mais rápido
- Melhor DX
- Automático
- Free tier generoso
- Perfeito para React + Vite

```bash
vercel --prod
```

---

**Última atualização: Fevereiro 2026**
